﻿using System;
using System.Collections.Generic;

namespace SingerApplication.Models
{
    public partial class Song
    {
        public int SongId { get; set; }
        public string SongName { get; set; } = null!;
        public int SingerId { get; set; }
        public string? SongTypeId { get; set; }
    }
}
