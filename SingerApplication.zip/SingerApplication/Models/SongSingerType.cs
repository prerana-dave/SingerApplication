﻿using System;
using System.Collections.Generic;

namespace SingerApplication.Models
{
    public partial class SongSingerType
    {
        public int SongSingerTypeId { get; set; }
        public int SongId { get; set; }
        public int SongTypeId { get; set; }
        public string SingerName { get; set; } = null!;
    }
}
