﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace SingerApplication.Models
{
    public partial class practicalContext : DbContext
    {
        public practicalContext()
        {
        }

        public practicalContext(DbContextOptions<practicalContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Song> Songs { get; set; } = null!;
        public virtual DbSet<SongSingerType> SongSingerTypes { get; set; } = null!;
        public virtual DbSet<SongType> SongTypes { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=10.61.18.12;Initial Catalog=practical;User ID=MSdba;Password=dba@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=True;Connection Timeout=30;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Song>(entity =>
            {
                entity.ToTable("Song");

                entity.Property(e => e.SongName).HasMaxLength(50);

                entity.Property(e => e.SongTypeId)
                    .HasMaxLength(10)
                    .IsFixedLength();
            });

            modelBuilder.Entity<SongSingerType>(entity =>
            {
                entity.ToTable("Song_Singer_Type");

                entity.Property(e => e.SongSingerTypeId).HasColumnName("Song_Singer_TypeId");

                entity.Property(e => e.SingerName).HasMaxLength(50);
            });

            modelBuilder.Entity<SongType>(entity =>
            {
                entity.ToTable("SongType");

                entity.Property(e => e.SongType1)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("SongType");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
