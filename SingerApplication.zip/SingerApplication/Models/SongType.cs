﻿using System;
using System.Collections.Generic;

namespace SingerApplication.Models
{
    public partial class SongType
    {
        public int SongTypeId { get; set; }
        public string SongType1 { get; set; } = null!;
    }
}
