﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SingerApplication.Models;
using System.Diagnostics;

namespace SingerApplication.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            var dbContext = new practicalContext();
            var songTypeList = dbContext.SongTypes.ToList();
            var songSingerTypesList = dbContext.SongSingerTypes.ToList();
            var songsList = dbContext.Songs.ToList();
            ViewBag.SongTypes = JsonConvert.SerializeObject(songTypeList);
            ViewBag.SongSingerTypes = JsonConvert.SerializeObject(songSingerTypesList);
            ViewBag.Songs = JsonConvert.SerializeObject(songsList);
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}